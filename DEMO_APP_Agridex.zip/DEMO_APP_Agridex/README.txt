Agridex Pilot Data Analysis Tool

Prerequisites:
- Python 3.7 or later (Download from https://www.python.org/downloads/)

Instructions:
1. Extract all files from the zip archive to a folder.
2. Double-click the 'run_agridex.bat' file.
3. The first run may take a few minutes to set up the environment and install required packages.
4. Once the application opens:
   - Click "Browse Excel File" to load your data.
   - Select features and a target variable from the loaded data.
   - Choose an analysis method and a plot type.
   - Click "Run Analysis" to perform the analysis and generate the plot.

If you encounter any issues, please contact [your contact information].
